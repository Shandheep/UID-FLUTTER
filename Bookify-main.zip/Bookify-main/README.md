# Bookify

A new Flutter project.

## Getting Started

<img src="ScreenShots/buy.jpg?raw=true" width="32%"> <img 
src="ScreenShots/carousel.jpg?raw=true" width="32%">
<img src="ScreenShots/login.jpg?raw=true" width="32%">
<img src="ScreenShots/signup.jpg?raw=true" width="32%">
<img src="ScreenShots/home.jpg?raw=true" width="32%">
<img src="ScreenShots/more.jpg?raw=true" width="32%">
<img src="ScreenShots/detail2.jpg?raw=true" width="32%">
<img src="ScreenShots/cod.jpg?raw=true" width="32%">
<img src="ScreenShots/drawer.jpg?raw=true" width="32%">
<img src="ScreenShots/buy.jpg?raw=true" width="32%">
<img src="ScreenShots/detail.jpg?raw=true" width="32%">
<img src="ScreenShots/chathome.jpg?raw=true" width="32%">
<img src="ScreenShots/chat.jpg?raw=true" width="32%">
<img src="ScreenShots/profile.jpg?raw=true" width="32%">
